{% extends "base.html" %}

{% block content %}
<h2>Printer Settings</h2>

<!-- Dark/Light Mode Toggle -->
<form method="POST">
    <label for="theme">Theme:</label>
    <select name="theme" id="theme" onchange="this.form.submit()">
        <option value="dark" {% if theme == 'dark' %}selected{% endif %}>Dark</option>
        <option value="light" {% if theme == 'light' %}selected{% endif %}>Light</option>
    </select>
</form>

<hr>

<!-- Admin Login -->
{% if not is_admin %}
<form method="POST" class="login-form">
    <h3>Admin Login</h3>
    <label for="username">Username:</label>
    <input type="text" name="username" id="username" required>
    
    <label for="password">Password:</label>
    <input type="password" name="password" id="password" required>
    
    <button type="submit" class="action-btn">Login</button>
</form>
{% else %}
<p><strong>Admin logged in.</strong></p>
<button onclick="alert('Here you could add printer setup options')">Configure Printers</button>
{% endif %}
{% endblock %}
